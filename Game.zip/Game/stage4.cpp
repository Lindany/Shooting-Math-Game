#include "stage4.h"
#include "stage.h"
#include <QString>

Stage4::Stage4(){
    bgImage_path=":/images/bg_48.png";
    logoImage_path=":/images/logo_multiple7.png";
    description_path="";
}

bool Stage4::check(int number){
    if(number%7==0)
        return true;
    else
        return false;
}
QString Stage4::getBg_image(){
    return bgImage_path;

}
QString Stage4::getLogo(){
    return logoImage_path;
}
QString Stage4::getDescr(){
    return description_path;
}
