#ifndef STAGE_H
#define STAGE_H
#include <QString>


class Stage{
public:

     bool isDone(int time);
    virtual bool check(int number)=0;
    virtual QString getBg_image()=0;
    virtual QString getLogo()=0;
    virtual QString getDescr()=0;
};

#endif // STAGE_H
