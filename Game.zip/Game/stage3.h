#ifndef STAGE3_H
#define STAGE3_H
#include "stage.h"

class Stage3 : public Stage{
public:

     Stage3();
     bool check(int number);
     QString getBg_image();
     QString getLogo();
     QString getDescr();
private:
     QString bgImage_path;
     QString logoImage_path;
     QString description_path;

};
#endif // STAGE3_H
