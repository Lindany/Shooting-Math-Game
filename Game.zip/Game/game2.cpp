#include "game2.h"
#include <QTimer>
#include <QGraphicsTextItem>
#include <QFont>
#include "Number.h"
#include <QMediaPlayer>
#include "images.h"
#include <QBrush>
#include <QImage>


Game2::Game2(QWidget *parent){
    // create the scene
    titleText = new QGraphicsTextItem(QString("typing"));
    playButton = new Button(QString("Play"));
    quitButton = new Button(QString("Quit"));
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,800,600); // make the scene 800x600 instead of infinity by infinity (default)

    setBackgroundBrush(QBrush(QImage(":/images/backpic.png")));

    // make the newly created scene the scene to visualize (since Game is a QGraphicsView Widget,
    // it can be used to visualize scenes)
    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(800,600);

    // create the player


    show();
}
void Game2::start(){

   scene->removeItem(titleText);
   scene->removeItem(playButton);
   scene->removeItem(quitButton);


   delete titleText;
   delete playButton;
   delete quitButton;




    // create the score/health
    score = new Score();
    scene->addItem(score);

    health = new Health();
    health->setPos(health->x()+650,health->y());

    scene->addItem(health);
    //QGraphicsTextItem* titleText = new QGraphicsTextItem(QString("ShOOt all the Even Numbers"));
    QGraphicsTextItem* gameOver = new QGraphicsTextItem(QString("GAME OVER"));


    QFont titleFont("comic sans",30);
    titleText->setFont(titleFont);
    titleText->setPos(105,4);
    titleText->setDefaultTextColor(Qt::gray);
    scene->addItem(titleText);

    gameOver->setPos(350,200);
    gameOver->setDefaultTextColor(Qt::red);

    // spawn enemies
    QTimer * timer = new QTimer();
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(creatLetter()));
    timer->start(1000);

    QMediaPlayer *backsound = new QMediaPlayer();
   // backsound->setMedia(QUrl("qrc:/sound/icantstopTrapng.mp3"));
    backsound->play();

}

void Game2::mainmenu(){

        QFont titleFont("comic sans",50);
        titleText->setFont(titleFont);
        int txPos = this->width()/2 - titleText->boundingRect().width()/2;
        int tyPos = 150;
        titleText->setPos(txPos,tyPos);
        scene->addItem(titleText);

        int bxPos = this->width()/2 - playButton->boundingRect().width()/2;
        int byPos = 275;
        playButton->setPos(bxPos,byPos);
        connect(playButton,SIGNAL(clicked()),this,SLOT(start()));
        scene->addItem(playButton);

        int qxPos = this->width()/2 - quitButton->boundingRect().width()/2;
        int qyPos = 350;
        quitButton->setPos(qxPos,qyPos);
        connect(quitButton,SIGNAL(clicked()),this,SLOT(close()));
        scene->addItem(quitButton);
}
void Game2::creatLetter(){

}
