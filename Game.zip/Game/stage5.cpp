#include "stage5.h"
#include "stage.h"
#include <QString>

Stage5::Stage5(){
    bgImage_path=":/images/bgImage.png";
    logoImage_path=":/images/logo_factors48.png";
    description_path="";
}

bool Stage5::check(int number){
    if(number==-1){
        return false;
    }

    if(48%number==0)
        return true;
    else
        return false;
}
QString Stage5::getBg_image(){
    return bgImage_path;

}
QString Stage5::getLogo(){
    return logoImage_path;
}
QString Stage5::getDescr(){
    return description_path;
}
