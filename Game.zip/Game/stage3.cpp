#include "stage3.h"
#include "stage.h"
#include <QString>

Stage3::Stage3(){
    bgImage_path=":/images/bg_composite.png";
    logoImage_path=":/images/logo_composite.png";
    description_path=":/images/p5.png";
}

bool Stage3::check(int number){
    if(number==1){
        return false;
    }
    for(int i=2;i<(number);i++){
        if(number%i==0){
            return true;
            break;
        }
    }
    return false;

}
QString Stage3::getBg_image(){
    return bgImage_path;

}
QString Stage3::getLogo(){
    return logoImage_path;
}
QString Stage3::getDescr(){
    return description_path;
}
