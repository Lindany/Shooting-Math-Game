#include "stage2.h"
#include "stage.h"
#include <QString>

Stage2::Stage2(){
    bgImage_path=":/images/bg_4.png";
    logoImage_path=":/images/logo_prime.png";
    description_path=":/images/p3.png";
}

bool Stage2::check(int number){
    if(number==1){
        return false;
    }
    for(int i=2;i<(number);i++){
        if(number%i==0){
            return false;
        }
    }
    return true;
}

QString Stage2::getBg_image(){
    return bgImage_path;

}

QString Stage2::getDescr(){
    return description_path;
}
QString Stage2::getLogo(){
    return logoImage_path;
}
