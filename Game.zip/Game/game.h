#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "tank.h"
#include "DisplayData.h"
#include "life.h"
#include "button.h"
#include "bestscore.h"
#include "logo.h"
#include "stage.h"
#include "stage1.h"
#include "stage2.h"
#include "stage3.h"
#include "stage4.h"
#include "stage5.h"
#include  <QVector>

using namespace std;


class Game: public QGraphicsView{
     Q_OBJECT
public:
    Game(QWidget * parent=0);

    QGraphicsScene * scene;
    Tank * player;
    DisplayData * score;
    DisplayData * bestscore;
    DisplayData * TIME;
    Logo *logo;


    QGraphicsTextItem* titleText;
    QGraphicsTextItem* time;
    Button* playButton;
    Button* quitButton;
    Button* restart;
    Button* nextStage;
    Button* startButton;
    Button* instructButton;
    Button* backButton;

    QMediaPlayer *backsound;
    QMediaPlayer *gameoversound;
    QTimer * timer;
    QTimer * stageTimer;

    //stages







    int getgame();

    QVector<QGraphicsPixmapItem*> life_vector; //to store the lifes of a player
    QVector<QGraphicsPixmapItem*> specialbullet_vector; //to store special bullets
    QVector<QString> image_vector; //to store images

    bool getboolvar();
    void setboolvar(bool tof);
   // QGraphicsPixmapItem* getNum();
    Life *life1 ;
    Life *life2 ;
    Life *life3 ;
    Life *life4 ;

    Life *spacial1;
    Life *spacial2;
    Life *spacial3;
    Life *spacial4;

    void playAgain();
    void gameOver();

    Stage1 *stage1;
    Stage2 *stage2;
    Stage3 *stage3;
    Stage4 *stage4;
    Stage5 *stage5;
    QVector<Stage*> vect;
    //QVector<Stage*>::Iterator iterate;
    int _time;

private:

    QVector<QGraphicsPixmapItem*> vectorForNum;
    int ScoreChanged;
    int speed;
    QMediaPlayer *explor;

    QVector<int> scoreStore;
    bool var;
    int game;
    int countnumbers;
public slots:
       void start();
       void mainmenu();
       void createNumber();
       void instructions();
       void stageDesc();
       void stageFinish();
       //void Stage2(int);
       void decre_time();
       void stageComplete();
       void gameComplete();
};

#endif // GAME_H
