#ifndef PICBULLET_H
#define PICBULLET_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>
#include <QMediaPlayer>

class Picbullet:public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Picbullet(QGraphicsItem * parent=0);


private:
    QMediaPlayer * LifeRemoveSound;
};

#endif // PICBULLET_H
