#ifndef STAGE5_H
#define STAGE5_H
#include "stage.h"
class Stage5 : public Stage{
public:

     Stage5();
     bool check(int number);
     QString getBg_image();
     QString getLogo();
     QString getDescr();
private:
     QString bgImage_path;
     QString logoImage_path;
     QString description_path;

};

#endif // STAGE5_H
