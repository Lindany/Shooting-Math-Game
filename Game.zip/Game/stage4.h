#ifndef STAGE4_H
#define STAGE4_H
#include "stage.h"
class Stage4 : public Stage{
public:

     Stage4();
     bool check(int number);
     QString getBg_image();
     QString getLogo();
     QString getDescr();
private:
     QString bgImage_path;
     QString logoImage_path;
     QString description_path;

};

#endif // STAGE4_H
