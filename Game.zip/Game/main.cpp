#include <QApplication>

#include "number.h"
#include "Game.h"

#include <iostream>



Game * game;

int main(int argc, char *argv[]){
    QApplication a(argc, argv);
    game = new Game();
    game->mainmenu();

    return a.exec();
}
