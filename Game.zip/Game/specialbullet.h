#ifndef SPACIALBULLET_H
#define SPACIALBULLET_H
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QMediaPlayer>

class Specialbullet:public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
     Specialbullet(QGraphicsItem * parent=0);

public slots:
    void move();
private:
    QMediaPlayer *explosion;
};

#endif // SPACIALBULLET_H
