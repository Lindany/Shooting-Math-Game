#include "number.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include <stdlib.h>
#include "Game.h"
#include <QDebug>
#include <time.h>

extern Game * game;

Number::Number(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent){
    //set random x position



    //srand(time(0));
    int random_number = rand() % 700;
    setPos(random_number,0);
    //srand(time(0));

    number = 1+rand()%10;
    //srand(time(0));

         if (number==1){
             //qDebug()<<number->getnum();
            //QString path =":/images/"+game->image_vector[number]+".png";
             int x =1;
             setpath(":/images/one.png");
         }
         else if (number==2){
            // qDebug()<<number->getnum();
             setpath(":/images/two.png");
         }
         else if (number==3){
            // qDebug()<<number->getnum();
             setpath(":/images/three.png");
         }
         else if (number==4){
            // qDebug()<<number->getnum();
             setpath(":/images/four.png");
         }
         else if (number==5){
            // qDebug()<<number->getnum();
             setpath(":/images/five.png");
         }
         else if (number==6){
            // qDebug()<<number->getnum();
             setpath(":/images/six.png");
         }
         else if (number==7){
            // qDebug()<<number->getnum();
             setpath(":/images/seven.png");
         }
         else if (number==8){
            // qDebug()<<number->getnum();
             setpath(":/images/eight.png");
         }
         else if (number==9){
            // qDebug()<<number->getnum();
             setpath(":/images/nine.png");
         }
         else if (number==10){
            // qDebug()<<number->getnum();
             setpath(":/images/ten.png");
         }

    // make/connect a timer to move() the number every so often

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    // start the timer

    timer->start(40);
    //this->incSpeed();
}

void Number::move(){

    setPos(x(),y()+Speed);
    if(game->getboolvar()==true){
        this->setnum(1);
        game->scene->removeItem(this);
        //delete this
    }

    if (pos().y() > 600){
        if (game->vect[0]->check(this->getnum())==true){
            if (game->life_vector.size()!=0){
                game->scene->removeItem(game->life_vector.at(game->life_vector.size()-1));
                game->life_vector.pop_back();
                //delete game->getlast();
            }
            if(game->life_vector.size()==0){
                game->gameOver();
                //game->clearNumVector();
            }
        }
        game->scene->removeItem(this);
        //game->removeNumFromVector(this);
        delete this;
    }
}
int Number::getnum(){
    return number;
}
void Number::setpath(QString path){
     setPixmap(QPixmap(path));
}
void Number::setSpeed(int speed){
    Speed=speed;
}
void Number::setnum(int num){
    number=num;
}
