#include "stage1.h"
#include "stage.h"
#include <QString>
#include <QDebug>

Stage1::Stage1(){
    bgImage_path=":/images/bgImage.png";
    logoImage_path=":/images/evennumber.png";
    description_path=":/images/p4.png";
}
bool Stage1::check(int number){
    if (number%2==0)
        return true;
     else
       return false;
}
QString Stage1::getBg_image(){
    return bgImage_path;
}
QString Stage1::getLogo(){
    return logoImage_path;
}
QString Stage1::getDescr(){
    return description_path;
}

