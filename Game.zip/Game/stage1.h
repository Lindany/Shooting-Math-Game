#ifndef STAGE1_H
#define STAGE1_H
#include "stage.h"

class Stage1 : public Stage{
public:
     Stage1();
     bool check(int number);
     QString getBg_image();
     QString getLogo();
     QString getDescr();

private:
     QString bgImage_path;
     QString logoImage_path;
     QString description_path;

};

#endif // STAGE1_H
