#include "bestscore.h"
#include <QFont>

Bestscore::Bestscore(QGraphicsItem *parent): QGraphicsTextItem(parent){
    bestscore=0;
    setPlainText(QString("BestScore: ") + QString::number(bestscore));
    setDefaultTextColor(Qt::gray);
    setFont(QFont("times",16));
    setPos(0,50);
}

void Bestscore::setbestscore(int score){
    bestscore=score;
    setPlainText(QString("BestScore: ") + QString::number(bestscore));
}

int Bestscore::getbestscore(){
    return bestscore;
}
