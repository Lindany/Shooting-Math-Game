#ifndef HEALTH_H
#define HEALTH_H

#include <QGraphicsTextItem>
#include <QVector>

class Health:public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Health(QGraphicsItem * parent=0);
    void decrease();
    int getHealth();
private:
    int health;
    QVector<QGraphicsPixmapItem> * vector;
};

#endif // HEALTH_H
