#ifndef SCORE_H
#define SCORE_H

#include <QGraphicsTextItem>

class DisplayData: public QGraphicsTextItem{
public:
    DisplayData(QString name, int value, QGraphicsItem * parent=0);
    void increase(int num);
    void decrease(int num);
    int getValue();
    void setValue(int num);
private:
    int value;
    QString name;
};

#endif // SCORE_H
