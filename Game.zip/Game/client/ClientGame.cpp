#include "stdafx.h"
#include "ClientGame.h"
#include "Data.h"

ClientGame::ClientGame(void) {
	network = new ClientNetwork();

	//send init coonnection packet
	const unsigned int packet_size = sizeof(Packet);
	char data[packet_size];

	//Packet pack;
	//pack.type = INIT_CONNECTION;

	//pack.into(data);

    //sendRoundEnd(MATH, 120, 3);

	//NetworkServices::sendMessage(network->clientSocket, data, packet_size);
}

void ClientGame::sendActions() {
	const unsigned int pack_size = sizeof(Packet);
	char data[pack_size];

	Packet pack;
	pack.type = ROUND_END;

	pack.into(data);

	NetworkServices::sendMessage(network->clientSocket, data, pack_size);
}

void ClientGame::refresh() {

	Packet pack;
	int dataSize = network->receivePacks(client_data);

	if (dataSize <= 0) {
		//none
		return;
	}

	printf("data size: %d\n", dataSize);

	unsigned int i = 0;
	while (i < (unsigned int)dataSize) {
		pack.outof(&(client_data[i]));
		i += sizeof(Packet);

		switch (pack.type) {

		case INIT_CONNECTION:
			printf("init connection received\n");
			break;

		case ROUND_END:
			printf("ROUND_END packet received\n");
			//sendActions();
			printf("\n");
			printf("packet_data\n");
			printf("packet type: %d\n", pack.type);
			printf("packet game: %d\n", pack.gamePlayed);
			printf("packet score: %d\n", pack.score);
			printf("packet stage: %d\n", pack.stage);
			printf("\n");
			printf("\n");

            //sendRoundEnd(type, score, stage);
			break;


		default:
			printf("other packet");
			break;
		}
	}
}

void ClientGame::sendRoundEnd(char* str, GameTypes gameType, int score, int stage) {
	char buffer[sizeof(Packet)];
	Packet pack;
	pack.type = ROUND_END;
	pack.gamePlayed = gameType;
	pack.score = score;
	pack.stage = stage;

	pack.into(buffer);

	//send
	NetworkServices::sendMessage(network->clientSocket, buffer, sizeof(Packet));
}
