#pragma once
//#include <winsock2.h>
//#include <Windows.h>
#include <stdio.h> 
#include "NetworkServices.h"
#include "Data.h"

//#pragma comment(lib, "ws2_32.lib")

//bufferL length
#define DEFAULT_BUFFERLEN 2048

// port to connect sockets through 
#define DEFAULT_PORT "6881"

// Need to link with Ws2_32.lib, Mswsock.lib, and Advapi32.lib
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

class ClientNetwork {
public:
	int iResult;//for error checking

	SOCKET clientSocket;

	int receivePacks(char* buffer);

	ClientNetwork();
	~ClientNetwork();
};