#include "stdafx.h"
#include "ClientNetwork.h"
//#include <ws2def.h>



ClientNetwork::ClientNetwork() {
	//WSDATA object
	WSAData data;

	//ClientNetwork's socket
	clientSocket = INVALID_SOCKET;

	//for address info
	addrinfo* result = NULL,
		*ptr = NULL,
		hints;

	//initialize winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &data);

	if (iResult != 0) {
		//winsock startup error
		//just quit
		return;
	}

	//set address info
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//resolve address info
	//for "LOCALHOST"
    iResult = getaddrinfo("10.3.6.204", DEFAULT_PORT, (const ADDRINFOA*)&hints, &result);

	if (iResult != 0) {
		//Must quit due tot error no iResult
		//std::cout << "Must quit duej to error number " << iResult << std::endl;
		printf("Must quit due to error number %1d\n", iResult);
		//winsock has initialised, must cleanup and exit
		WSACleanup();
		exit(1);
	}

	//Attempt connection
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {

		//create socket for connection
		clientSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
		//error handling
		if (clientSocket == INVALID_SOCKET) {
			printf("couldnt create socket, error no %1d\n", WSAGetLastError());
			WSACleanup();
			exit(1);
		}

		//try connecting
		iResult = connect(clientSocket, ptr->ai_addr, (int)ptr->ai_addrlen);

		if (iResult == SOCKET_ERROR) {
			printf("couldn't connect due to server being down...\n");
			closesocket(clientSocket);
			clientSocket = INVALID_SOCKET;
		}

		//free result(server info)
		freeaddrinfo(result);

		//handle connection error
		if (clientSocket == INVALID_SOCKET) {
			printf("Unable to connect\n");
			closesocket(clientSocket);
			WSACleanup();
            //exit(1);
            return;
		}


		//set mode of socket to be non-blocking
		u_long mode = 1;

		iResult = ioctlsocket(clientSocket, FIONBIO, &mode);

		if (iResult == SOCKET_ERROR) {
			printf("couldn't set mode of socket. error no %1d\n", WSAGetLastError());
			closesocket(clientSocket);
			WSACleanup();
			exit(1);
		}

		//disbale nagle???????what is nagle?
		char value = '1';
		setsockopt(clientSocket, IPPROTO_TCP, TCP_NODELAY, &value, sizeof(value));
	}



}

int ClientNetwork::receivePacks(char* buffer) {
	iResult = NetworkServices::receive(clientSocket, buffer, MAX_PACKET_SIZE);

	if (iResult == 0) {
		printf("connection dead x_x");
		closesocket(clientSocket);
		WSACleanup();
		exit(1);
	}

	return iResult;
}

ClientNetwork::~ClientNetwork() {
	closesocket(clientSocket);
}
