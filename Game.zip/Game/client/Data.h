#pragma once
#include <string>
#include <iostream>

#define MAX_PACKET_SIZE 2000000

using namespace std;

//ENUMERATION OF TRANSFERRABLE DATA
//should add more types for brevity
enum PacketTypes { INIT_CONNECTION = 0, ROUND_END = 1 };
enum GameTypes { TYPING = 0, MATH = 1 };

struct Packet {
	/*Packet() {}
	Packet(PacketTypes type, string playerName, GameTypes gamePlayed, int score) {
	this->type = type;
	this->playerName = playerName;
	this->gamePlayed = gamePlayed;
	this->score = score;
	}
	*/
	PacketTypes type;
	//int totalPackets;
	//string playerName;
	GameTypes gamePlayed;
	int score;
	int stage;
	//add more stuff like
	//-game  played
	//-progress/score

	//moves Packets info into data
	void into(char* data) {
		memcpy(data, this, sizeof(Packet));
	}

	//moves packet info from data to Packet
	void outof(char* data) {
		memcpy(this, data, sizeof(Packet));
	}

};