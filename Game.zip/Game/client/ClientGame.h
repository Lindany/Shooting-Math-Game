#pragma comment(lib, "ws2_32.lib")

#pragma once
#include "ClientNetwork.h"
//#include <WinSock2.h>
//#include <Windows.h>
//#include "Data.h"

//#pragma comment(lib, "ws2_32.lib")

class ClientGame {
public:
	void sendActions();

    void sendRoundEnd(char* str, GameTypes gameplayed, int score, int stage);

	char client_data[MAX_PACKET_SIZE];

	void refresh();

	ClientGame(void);
	~ClientGame(void);

	ClientNetwork* network;
};
