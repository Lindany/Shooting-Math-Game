// MainClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdafx.h"
#include "ClientGame.h"
#include <thread>

void clientRun();

//ClientGame* clientGame;


//Entry Point
int main(void* args) {


	//initialise client
    //clientGame = new ClientGame();

	//clientGame->clientThread = std::thread(clientRun);

	//while (true) {
	//clientGame->sendPacket();
	//}
	std::thread thrd = std::thread(clientRun);

	thrd.join();
	//clientRun();


}


void clientRun() {
	while (true) {

		clientGame->refresh();
		//clientGame->sendPacket();
	}
}
