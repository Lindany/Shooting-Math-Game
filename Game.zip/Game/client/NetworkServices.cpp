#include "stdafx.h"
#include "NetworkServices.h"

#include <ws2def.h>

#pragma comment(lib, "ws2_32.lib")

class NetworkServices;

int NetworkServices::sendMessage(SOCKET socket, char* message, int messageSize) {
	return send(socket, message, messageSize, 0);
}

int NetworkServices::receive(SOCKET socket, char* buffer, int bufferSize) {
	return recv(socket, buffer, bufferSize, 0);
}