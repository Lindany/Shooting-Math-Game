#pragma once
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <Windows.h>



#pragma comment(lib, "ws2_32.lib")


class NetworkServices {

public:
	static int sendMessage(SOCKET socket, char* message, int messageSize);

	static int receive(SOCKET socket, char* buffer, int bufferSize);
};
