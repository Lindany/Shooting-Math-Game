#ifndef NUMBER_H
#define NUMBER_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>


class Number: public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Number(QGraphicsItem * parent=0);
    void setpath(QString path);
    int getnum();
    void setnum(int num);
    void setSpeed(int speed);
    QTimer * timer ;
public slots:
    void move();
private:
    int number;
    int Speed;
};
#endif // NUMBER_H
