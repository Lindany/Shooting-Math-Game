#include "DisplayData.h"
#include <QFont>

DisplayData::DisplayData(QString name,int value,QGraphicsItem *parent): QGraphicsTextItem(parent){

    this->value=value;
    this->name=name;

    setDefaultTextColor(Qt::gray);
    setFont(QFont("times",16));
}

void DisplayData::increase(int num){
    value+=num;
    setPlainText(QString(name) +" "+ QString::number(value));
}
void DisplayData::decrease(int num){
    value-=num;
    setPlainText(QString(name) +" "+ QString::number(value));
}

int DisplayData::getValue(){
    return value;
}
void DisplayData::setValue(int num){
    value=num;
    setPlainText(QString(name) +" "+ QString::number(value));
}
