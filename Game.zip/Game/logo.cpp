#include "logo.h"
#include <QGraphicsScene>

Logo::Logo( QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    setPos(215,0);
}
void Logo::setLogo(QString logo){
    setPixmap(QPixmap(logo));
}
