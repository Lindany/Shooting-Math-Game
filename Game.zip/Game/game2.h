#ifndef GAME2_H
#define GAME2_H

#include <QGraphicsView>
#include <QWidget>
#include <QGraphicsScene>
#include "Player.h"
#include "Score.h"
#include "Health.h"
#include "button.h"


class Game2: public QGraphicsView{
     Q_OBJECT
public:
    Game2(QWidget * parent=0);

    QGraphicsScene * scene;
    Player * player;
    Score * score;
   // Score * scor;
    Health * health;
    QGraphicsTextItem* titleText;
    QGraphicsTextItem* gameOver;
    Button* playButton;
    Button* quitButton;

    void mainmenu();
public slots:
       void start();
       void creatLetter();
};



#endif // GAME2_H
