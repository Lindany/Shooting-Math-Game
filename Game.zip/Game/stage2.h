#ifndef STAGE2_H
#define STAGE2_H
#include "stage.h"

class Stage2 : public Stage{
public:
     Stage2();
     bool check(int number);
     QString getBg_image();
     QString getLogo();
     QString getDescr();
private:
     QString bgImage_path;
     QString logoImage_path;
     QString description_path;

};



#endif // STAGE2_H
