
#include "Game.h"
#include <QTimer>
#include <QGraphicsTextItem>
#include <QFont>
#include "Number.h"
#include <QMediaPlayer>
#include "images.h"
#include <QBrush>
#include <QImage>
#include <QDebug>
#include <life.h>
#include <chrono>
#include <QList>

#include <client\ClientGame.h>
#include <thread>


#include "stage1.h"
#include "stage2.h"
#include "stage3.h"


//using clinet;
ClientGame* clientGame;
void run();
std::thread thrd;

void run(){
    while(true){
        clientGame->refresh();
    }
}

Game::Game(QWidget *parent){

    titleText = new QGraphicsTextItem(QString("MINI-MATH"));
    time = new QGraphicsTextItem();
    playButton = new Button(QString("Play"));
    quitButton = new Button(QString("Quit"));
    restart = new Button(QString("Restart"));
    nextStage = new Button(QString("Next"));
    instructButton = new Button(QString("Instructions"));
    startButton = new Button(QString("Start"));
    backButton = new Button(QString("back"));
    explor = new QMediaPlayer();

   stage1 =new Stage1();
   vect.push_back(stage1);

   stage2 = new Stage2();
   vect.push_back(stage2);

   stage3 = new Stage3();
   vect.push_back(stage3);

//   stage4 = new Stage4();
//   vect.push_back(stage4);

//  stage5 = new Stage5();
//  vect.push_back(stage5);

    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,800,600); //
    setBackgroundBrush(QBrush(QImage(":/images/theme")));


    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(800,600);

    player = new Tank();
    player->setFlag(QGraphicsItem::ItemIsFocusable);
    score = new DisplayData("Score",0);
    bestscore = new DisplayData("Best_Score",0);
    TIME = new DisplayData("Time",60);
    timer = new QTimer();
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(createNumber()));

    stageTimer = new QTimer();
    QObject::connect(stageTimer,SIGNAL(timeout()),this,SLOT(decre_time()));

    backsound = new QMediaPlayer();

    backsound->setVolume(50);

    life1 = new Life(":/images/oneUp.png");
    life2 = new Life(":/images/oneUp.png");
    life3 = new Life(":/images/oneUp.png");
    life4 = new Life(":/images/oneUp.png");

    spacial1 = new Life(":/images/spacial.png");
    spacial2 = new Life(":/images/spacial.png");
    spacial3 = new Life(":/images/spacial.png");
    spacial4 = new Life(":/images/spacial.png");

   QStringList imagelist ;
   imagelist<<"ay"<<":/images/one.png"<<"two"<<"three"<<"four"<<"five"<< "six"<< "seven"<< "eight"<< "nine"<< "tene"<<"even"<<"twelve"<<"thirteen"<<"fourteen"<<"fifteen"<<"sixteen"<<"seventeen"<<"eighteen"<<"nineteen"<<"twenty";

     QVector<QString> image_vector = QVector<QString>::fromList(imagelist);
      qDebug()<<image_vector[1];
    logo = new Logo();
    show();


    //try adding the dll
//    QLibrary lib;
//    QString path = "/CliNet.dll";

//    if(QLibrary::isLibrary(path)){
//        qDebug() << "Loading CliNet.dll\n";

//        lib.setFileName(path);
//        lib.load();
//        if(lib.isLoaded()){
//            qDebug() << "Library loaded";
//        }else{
//            qDebug() << "Library Cannot Be Loaded \n";
//        }

//    }else{
//        qDebug() << path << "  is not a library";
//    }
   clientGame = new ClientGame();


    //thrd.join();

}




void Game::start(){\
    //qDebug()<<vect.size();
    if (backsound->state() == QMediaPlayer::PlayingState){
        backsound->stop();
    }

    this->setboolvar(false);

    scene->removeItem(nextStage);
    scene->removeItem(playButton);
    scene->removeItem(quitButton);
    scene->removeItem(restart);
    scene->removeItem(titleText);

    while (specialbullet_vector.size()>0){
        scene->removeItem(specialbullet_vector.at(specialbullet_vector.size()-1));
        specialbullet_vector.remove(specialbullet_vector.size()-1);

    }
    while (life_vector.size()>0){
        scene->removeItem(life_vector.at(life_vector.size()-1));
        life_vector.remove(life_vector.size()-1);
    }


    life_vector.push_back(life1);
    life_vector.push_back(life2);
    life_vector.push_back(life3);
    life_vector.push_back(life4);

    specialbullet_vector.push_back(spacial1);
    specialbullet_vector.push_back(spacial2);
    specialbullet_vector.push_back(spacial3);
    specialbullet_vector.push_back(spacial4);

    int x =700;
    for(int i=0; i<life_vector.size(); i++){
        life_vector.at(i)->setPos(x,0);
        scene->addItem(life_vector.at(i));
        x+=25;

    }
    int z =700;
    for(int i=0; i<specialbullet_vector.size(); i++){
        specialbullet_vector.at(i)->setPos(z,50);
        scene->addItem(specialbullet_vector.at(i));
        z+=25;
    }

    setBackgroundBrush(QBrush(QImage(vect[0]->getBg_image())));
    player->setPos(380,500);
    scene->addItem(player);
    player->setFocus();
    scene->addItem(score);

    logo->setLogo(vect[0]->getLogo());
    scene->addItem(logo);

    score->setValue(0);
    score->setPos(0,0);
    scene->addItem(score);

    TIME->setValue(60);
    TIME->setPos(0,50);
    scene->addItem(TIME);

    backsound->setMedia(QUrl("qrc:/sounds/bg_sound.mp3"));
    backsound->play();

    timer->start(900);

    //time->sett
    speed=2;
    _time= 60;
    stageTimer->start(1000);


}
void Game::mainmenu(){

        QFont sansFont("Helvetica [Cronyx]",100);
        titleText->setFont(sansFont);
        int txPos = this->width()/2 - titleText->boundingRect().width()/2;
        int tyPos = 100;
        titleText->setPos(txPos,tyPos);
        scene->addItem(titleText);

        int bxPos = this->width()/2 - startButton->boundingRect().width()/2;
        int byPos = 275;
        startButton->setPos(bxPos,byPos);
        connect(startButton,SIGNAL(clicked()),this,SLOT(stageDesc()));
        scene->addItem(startButton);

        int ixPos = this->width()/2 - instructButton->boundingRect().width()/2;
        int iyPos = 350;
        instructButton->setPos(ixPos,iyPos);
        connect(instructButton,SIGNAL(clicked()),this,SLOT(instructions()));
        scene->addItem(instructButton);


        int qxPos = this->width()/2 - quitButton->boundingRect().width()/2;
        int qyPos = 420;
        quitButton->setPos(qxPos,qyPos);
        connect(quitButton,SIGNAL(clicked()),this,SLOT(close()));
        scene->addItem(quitButton);

        scene->removeItem(backButton);
        thrd = std::thread(run);

}

void Game::gameOver(){
    //send scores to server
    int score_ = this->score->getValue();
    clientGame->sendRoundEnd("",MATH, score_, 1);//index of the vector for the stage

    this->setboolvar(true);
    scoreStore.clear();
    //remove the special bullets from the scene and from the vector
    while (specialbullet_vector.size()>0){
        scene->removeItem(specialbullet_vector.at(specialbullet_vector.size()-1));
        specialbullet_vector.remove(specialbullet_vector.size()-1);
    }
    backsound->stop();
    backsound->setMedia(QUrl("qrc:/sounds/gameoversound.wav"));
    scene->removeItem(player);
    scene->removeItem(logo);

    backsound->play();
    backsound->setPosition(1);

    setBackgroundBrush(QBrush(QImage(":/images/gameover.png")));
    timer->stop();
    stageTimer->stop();
    quitButton->setPos(15,500);
    restart->setPos(590,500);
    connect(restart,SIGNAL(clicked()),this,SLOT(start()));
    scene->addItem(restart);
    scene->addItem(quitButton);
}

void Game::instructions(){
    scene->removeItem(instructButton);
    scene->removeItem(titleText);
    scene->removeItem(startButton);
    setBackgroundBrush(QBrush(QImage(":/images/p2.png")));
    quitButton->setPos(15,500);
    backButton->setPos(590,500);
    scene->addItem(backButton);
    connect(backButton,SIGNAL(clicked()),this,SLOT(mainmenu()));
}
void Game::stageDesc(){
    scene->removeItem(titleText);
    scene->removeItem(startButton);
    scene->removeItem(quitButton);
    scene->removeItem(instructButton);
    setBackgroundBrush(QBrush(QImage(vect[0]->getDescr())));
    int bxPos = this->width()/2 - playButton->boundingRect().width()/2;
    int byPos = 540;
    playButton->setPos(bxPos,byPos);
    scene->addItem(playButton);
    connect(playButton,SIGNAL(clicked()),this,SLOT(start()));

}
void Game::stageComplete(){
    this->setboolvar(true);
    scoreStore.clear();
    setBackgroundBrush(QBrush(QImage(":/images/P1.png")));
    //remove the special bullets from the scene and from the vector

   //qDebug()<<life_vector.size();
    backsound->pause();
    scene->removeItem(player);
    scene->removeItem(logo);
    nextStage->setPos(590,500);
    quitButton->setPos(15,500);
    restart->setPos(295,500);
    connect(restart,SIGNAL(clicked()),this,SLOT(start()));
    connect(nextStage,SIGNAL(clicked()),this,SLOT(stageFinish()));
    scene->addItem(nextStage);
    scene->addItem(quitButton);
    scene->addItem(restart);
}

void Game::stageFinish(){
    if(vect.size()==2){
        this->gameComplete();
}
    scene->removeItem(quitButton);
    scene->removeItem(restart);
    scene->removeItem(nextStage);

     //vect.removeAt(0);

     vect.removeAt(0);

     qDebug()<<vect.size();
     this->stageDesc();
}
void Game::gameComplete(){
    qDebug()<<"iyangena";
    timer->stop();
    scene->removeItem(player);
    setBackgroundBrush(QBrush(QImage(":/images/gameover.png")));

}

void Game::createNumber(){
    if (vect[0]->isDone(TIME->getValue())==true){
        timer->stop();
        stageTimer->stop();
        this->stageComplete();
    }
    Number * number = new Number();
    int temp = score->getValue();
    if(temp>0 && temp%10==0){
            if(!scoreStore.contains(temp)){
               scoreStore.append(temp);
               speed+= 2;
            }
    }
   number->setSpeed(speed);
   scene->addItem(number);

    if (backsound->state() == QMediaPlayer::StoppedState){
       backsound->play();
   }

}
bool Game::getboolvar(){
    return var;
}
void Game::setboolvar(bool tof){
    var=tof;
}
void Game::decre_time(){

    TIME->decrease(1);
}

