#include "stage.h"
#include <QDebug>


bool Stage::isDone(int time){
   if (time==0 || time <0){
        return true;
    }
    else
        return false;
}
