#ifndef IMAGES_H
#define IMAGES_H
#include <vector>
#include <iostream>
using namespace std;

class Images{
public:
    string getimage;

private:
string paths[9];

};

#endif // IMAGES_H
