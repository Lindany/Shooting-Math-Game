#ifndef MYVECTOR_H
#define MYVECTOR_H


#include <QMainWindow>
#include <QObject>

#include <QSharedDataPointer>
#include <QWidget>

class MyvectorData;

class Myvector
{
public:
    Myvector();
    Myvector(const Myvector &);
    Myvector &operator=(const Myvector &);
    ~Myvector();

private:
    QSharedDataPointer<MyvectorData> data;
};

#endif // MYVECTOR_H
