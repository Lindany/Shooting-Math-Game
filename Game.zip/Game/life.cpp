#include "life.h"
#include <QGraphicsScene>

Life::Life(QString name,QGraphicsItem *parent): QGraphicsPixmapItem(parent){

    LifeRemoveSound = new QMediaPlayer();
    LifeRemoveSound  = new QMediaPlayer();
    LifeRemoveSound ->setMedia(QUrl("qrc:/sound/shoot.wav"));

    setPixmap(QPixmap(name));
}

