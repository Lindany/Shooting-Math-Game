#include "tank.h"
#include <QGraphicsScene>
#include <QKeyEvent>
#include "Bullet.h"
#include "specialbullet.h"
#include "number.h"
#include "game.h"
extern Game * game;
Tank::Tank(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    // set bullet sound
    mediaplayer = new QMediaPlayer();
    mediaplayer->setVolume(100);

    // set graphic
    setPixmap(QPixmap(":/images/realTank.png"));
}

void Tank::keyPressEvent(QKeyEvent *event){
    // move the player left and right
    if (event->key() == Qt::Key_Left){
        if (pos().x() > 0)
        setPos(x()-15,y());
    }

    else if (event->key() == Qt::Key_Right){
        if (pos().x() + 100 < 800)
        setPos(x()+15,y());
    }
    // shoot with the spacebar
    else if (event->key() == Qt::Key_Space){
        // create a bullet
        Bullet * bullet = new Bullet();
        bullet->setPos(x()+36,y());
        game->scene->addItem(bullet);
        mediaplayer->setMedia(QUrl("qrc:/sounds/shoot.wav"));

        // play bulletsound
        if (mediaplayer->state() == QMediaPlayer::PlayingState){
            mediaplayer->setPosition(0);
        }
        else if (mediaplayer->state() == QMediaPlayer::StoppedState){
            mediaplayer->play();
        }

    }
    //shoot with S to get the special bullet
    else if (event->key()==Qt::Key_S){

        if(game->specialbullet_vector.size()>0){
                Specialbullet * bullet = new Specialbullet();
                bullet->setPos(x()+36,y());
                game->scene->addItem(bullet);
                game->scene->removeItem(game->specialbullet_vector.at(game->specialbullet_vector.size()-1));
                game->specialbullet_vector.pop_back();

                    mediaplayer->setMedia(QUrl("qrc:/sounds/spcial.wav"));
                if (mediaplayer->state() == QMediaPlayer::PlayingState){
                    mediaplayer->setPosition(0);
                }
                else if (mediaplayer->state() == QMediaPlayer::StoppedState){
                    mediaplayer->play();
                }
                //game->scene->removeItem(game->specialbullet_vector.at(game->specialbullet_vector.size()-1));
                //game->specialbullet_vector.remove(game->specialbullet_vector.size()-1);

            }
            else{
            mediaplayer->setMedia(QUrl("qrc:/sounds/notBullets.wav"));
            mediaplayer->play();
        }
    }
}


